document.getElementById("detectBtn").addEventListener("click", async () => {
  const text = document.getElementById("journal").value;
  if (!text) return alert("Write something first!");

  const response = await fetch("/detect-emotion", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text }),
  });

  const data = await response.json();
  document.getElementById("result").innerText = "Detected Emotion: " + data.emotion;
});
