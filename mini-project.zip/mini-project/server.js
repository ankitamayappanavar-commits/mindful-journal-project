import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// Configure OpenAI
const openai = new OpenAI({
  apiKey: "YOUR_OPENAI_API_KEY"
});

app.post("/detect-emotion", async (req, res) => {
  try {
    const { text } = req.body;
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "You are an emotion detection assistant." },
        { role: "user", content: `Detect the emotion (Happy, Sad, Angry, Neutral) in this text: "${text}"` },
      ],
    });
    res.json({ emotion: response.choices[0].message.content.trim() });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error detecting emotion" });
  }
});

app.listen(3000, () => console.log("Server running on http://localhost:3000"));
